# Import random to pick random indexes
import random
import queue as q

temp = [0, 1, 2, 3, 4, 5, 6, 7, 8]
random.shuffle(temp)
# Define a goal state puzzle board representation

puzzle = [[temp[0], temp[1], temp[2]], [temp[3], temp[4], temp[5]], [temp[6], temp[7], temp[8]]]

goal_state = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 0]
]

# print(puzzle)

def printPuzzle(puzzle):
    for row in puzzle:
        print("-------------")
        print("|", row[0], "|", row[1], "|", row[2], "|")
        print("-------------")


def printgoal(goal_state):
    for row in goal_state:
        print("-------------")
        print("|", row[0], "|", row[1], "|", row[2], "|")
        print("-------------")


# Define a function to shuffle the puzzle
def shufflePuzzle(puzzle):
    # Get the initial number of rows and columns in the puzzle
    rows = len(puzzle)
    cols = len(puzzle[0])

    # Find the position of the empty square
    empty_row = 0
    empty_col = 0

    for i in range(rows):
        for j in range(cols):
            if (puzzle[i][j] == 0):
                empty_row = i
                empty_col = j

    # print("Empty Index")
    # print(empty_row, empty_col)

    # Shuffle the puzzle by randomly swapping the empty square with a neighboring square
    for i in range(100):
        row = random.randint(-1, 1) + empty_row
        col = random.randint(-1, 1) + empty_col

        # Picked row and column is between the defined range
        if 0 <= row < rows and 0 <= col < cols:
            puzzle[empty_row][empty_col], puzzle[row][col] = puzzle[row][col], puzzle[empty_row][empty_col]
            empty_row, empty_col = row, col


def findIndex(puzzle):

    empty_row = 0
    empty_col = 0

    rows = len(puzzle)
    cols = len(puzzle[0])

    row, col = None, None
    for i in range(len(puzzle)):
        for j in range(len(puzzle[0])):
            if puzzle[i][j] == 0:
                row, col = i, j
                break

    index = [row,col]

    return index


def isSolved(puzzle):
    # Observe the goal state puzzle and solution are the same in this case
    solution = goal_state

    # Returns true or false
    return puzzle == solution

while not isSolved(puzzle):
    printPuzzle(puzzle)

    solution = goal_state
    # Ask the user for a move
    theMove = 0

    # Find the position of the square to move
    index = findIndex(puzzle)
    row = index[0]
    col = index[1]

    # Check if the square can be moved
    if row is not None:
        # Check if the empty square is above the selected square
        if row > 0 and puzzle[row - 1][col] == 0: #move up
            # Swap the selected square and the empty square
            puzzle[row][col], puzzle[row - 1][col] = puzzle[row - 1][col], puzzle[row][col]
        # Check if the empty square is below the selected square
        elif row < len(puzzle) - 1 and puzzle[row + 1][col] == 0:  #move down
            # Swap the selected square and the empty square
            puzzle[row][col], puzzle[row + 1][col] = puzzle[row + 1][col], puzzle[row][col]
        # Check if the empty square is to the left of the selected square
        elif col > 0 and puzzle[row][col - 1] == 0: #move left
            # Swap the selected square and the empty square
            puzzle[row][col], puzzle[row][col - 1] = puzzle[row][col - 1], puzzle[row][col]
        # Check if the empty square is to the right of the selected square
        elif col < len(puzzle[0]) - 1 and puzzle[row][col + 1] == 0:    #move right
            # Swap the selected square and the empty square
            puzzle[row][col], puzzle[row][col + 1] = puzzle[row][col + 1], puzzle[row][col]

printPuzzle(puzzle)
print("\n")
printgoal(goal_state)
shufflePuzzle(puzzle)
print(puzzle)
print(puzzle)
print(findIndex(puzzle))
print(isSolved(puzzle))