source_Puzz = [0,1,3,4,2,5,7,8,6]
dest_Puzz = [1,2,3,4,5,6,7,8,0]

def DisplayPuzz(sourcePuzz):
  j = 1
  for i in range(len(sourcePuzz)):
    if(j%3):
      print(sourcePuzz[i],end=" ")
    else:
      print(sourcePuzz[i])
    j+=1


def move_left(state):
    new_state = state[:]
    index = new_state.index(0)
    if index not in [0, 3, 6]:
        temp = new_state[index - 1]
        new_state[index - 1] = new_state[index]
        new_state[index] = temp
        return new_state
    else:
        return None

def move_right(state):
    new_state = state[:]
    index = new_state.index(0)
    if index not in [2, 5, 8]:
        temp = new_state[index + 1]
        new_state[index + 1] = new_state[index]
        new_state[index] = temp
        return new_state
    else:
        return None


def move_up(state):
    new_state = state[:]
    index = new_state.index(0)
    #print("------ index-------", index)
    if index not in [0, 1, 2]:
        temp = new_state[index - 3]
        new_state[index - 3] = new_state[index]
        new_state[index] = temp
        return new_state
    else:
        return None


def move_down(state):
    new_state = state[:]
    index = new_state.index(0)
    # print(index)
    if index not in [6, 7, 8]:
        temp = new_state[index + 3]
        new_state[index + 3] = new_state[index]
        new_state[index] = temp
        return new_state
    else:
        return None 

def DFS(sourcePuzz):
  no_of_iter = 0
  visited = [sourcePuzz]
  queue = [sourcePuzz]
  while(queue):
    s = queue.pop()
    no_of_iter += 1
    # print(s)  
    if(s == dest_Puzz):
      print("Reached Final State")
      DisplayPuzz(s)
      return no_of_iter
    newArr = []
    newArr.append(move_right(s))
    newArr.append(move_up(s))
    newArr.append(move_down(s))
    newArr.append(move_left(s))
    for i in newArr:
      if i not in visited and i != None:
        visited.append(i)
        queue.append(i)

def IDFS(sourcePuzz,depth):
  nextDepth = 0
  no_of_iter = 0
  visited = [sourcePuzz]
  queue = [sourcePuzz]
  while(queue):
    s = queue.pop()
    no_of_iter += 1
    print("S",s)  
    if(s == dest_Puzz):
      print("Reached Final State")
      DisplayPuzz(s)
      return no_of_iter
    newArr = []
    newArr.append(move_right(s))
    print("newArr after move right",newArr)
    newArr.append(move_up(s))
    print("newArr after move up",newArr)
    newArr.append(move_down(s))
    print("newArr after move down",newArr)
    newArr.append(move_left(s))
    print("newArr after move left",newArr)
    if nextDepth <= depth:
      for i in newArr:
        print( "i",i )
        if i not in visited and i != None:
          print("visited before append",visited)
          visited.append(i)
          print("visited after append",visited)
          print("queue before append",queue)
          queue.append(i)
          print("queue after append",queue)
        print("nextDepth",nextDepth)
        nextDepth+=1
    else:
      print("nextDepth",nextDepth)
      nextDepth-=1

print("Initial State")
DisplayPuzz(source_Puzz)
iteration =DFS(source_Puzz)
print("No of iternations in DFS",iteration )

# print("No of iternations in IDFS")
# IDFS(source_Puzz,400)
  