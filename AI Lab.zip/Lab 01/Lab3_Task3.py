biodata = ["Faizan","20I0565","2.32","AI","Data","Numerical Computing"]

print(biodata[0]+" "+ biodata[3]+" " +biodata[4])