#Task1
biodata = ["Faizan Pervaz", "20I-0565", "Faisalabad", 18]

for i in range(0 , 4):
    print(biodata[i])

