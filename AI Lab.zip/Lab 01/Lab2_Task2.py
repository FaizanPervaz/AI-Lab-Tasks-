str1 = "The Lyrics is not that poor"
result = ""
notindex = -1
poorindex = -1

if "not" in str1:
    notindex = str1.index("not")
    poorindex = str1.index("poor")

if notindex < poorindex and notindex != -1:
    result = str1.replace(str1[notindex : poorindex+len('poor')],('Good'))
    print(result)
else:
    print(str1)
