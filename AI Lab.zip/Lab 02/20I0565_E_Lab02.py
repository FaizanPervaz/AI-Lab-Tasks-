import numpy as np
from numpy import random
# print("Task01")
# print(np.array([1,2,3]))
# print("Task02")
# print(np.array([1,2,3],float))
# print("Task03")
# print(np.array([i for i in range(11)]))
# print("Task04")
# print(np.linspace(0,23,7))
# print("Task05")
# array = np.full((3,3), 5)
# # print(array)
# print("Task06")
# array1=np.squeeze(array)
# print(array1)
# print("Task07")
# arr = np.array([1,2,3,4,5,6,7,8,9])
# arr = np.reshape(arr,(3,3))
# print(arr)
# print("Task08")
# arr = np.random.normal(21, 4.5, (3, 3, 12, 3))
# mean=np.mean(arr)
# print(mean)
# std=np.std(arr)
# print(std)
# var=np.var(arr)
# print(var)
# max=np.max(arr)
# print(max)
# min=np.min(arr)
# print(min)

# print("Task09")
# arr = np.random.normal(21, 4.5, (3, 3, 12, 3))
# arr= arr.reshape(2,162)
# mean=np.mean(arr)
# print(mean)
# std=np.std(arr)
# print(std)
# var=np.var(arr)
# print(var)
# max=np.max(arr)
# print(max)
# min=np.min(arr)
# print(min)

# print("Task10")
# print("[1,2,3,4]")












